clear;
clc;
data = load('data.csv');
X = data(1:9,1:3);
y = data(1:9,4);
pos = find(y==1); 
neg = find(y == 0);
plot3(X(pos, 1), X(pos, 2),X(pos,3), 'k+','LineWidth', 2, ...
    'MarkerSize', 7);
hold on;
plot3(X(neg, 1), X(neg, 2),X(neg,3), 'ko','MarkerFaceColor', 'y', ...
    'MarkerSize', 7);
xlabel('height');
ylabel('weight');
zlabel('age');
[rows columns] = size(X);
[X_norm] = normalize(X);
alpha = 0.1;
X = [ones(rows,1),X_norm];
theta = zeros(columns+1,1);
[theta, J_history,h] = gradientdescent2(X,y,theta,alpha);
old_theta = theta;
data = load('Du.csv');
test = data(:,:);
test_norm = normalize(test);
l = length(test);
test = [ones(l,1) test_norm];
p = zeros(l,1);
z = test*theta;
p = sigmoid(z);
%p = round(p)
flag = 1;
men = double(1.0000);
n=1;
while flag~=34
    %n = 1;
    alpha = 0.1;
    m = 1;
    for k = 1:length(p)
        r = p(k,:);
        if( r>=0.90)
            temp = test(k,:);
            X(rows+n,:) = test(k,:);
            %test(k,:) = [];
            %temp1(n,1) = k;
            y(rows+n,:) = 1;
            n = n+1;
        elseif(r<=0.0001)
            temp = test(k,:);
            X(rows+n,:) = test(k,:);
            %test(k,:) = [];
            %temp1(n,1) = k;
            y(rows+n,:) = 1;
            n = n+1;
        else
            temp1(m,:) = test(k,:);
            m = m+1;
        end
        
       
        
        
    end
    %for j = 1:length(temp1)
     %   k = temp1(j,:);
      %  test(k,:) = [];
    %end
    theta = zeros(columns+1,1);
    [theta, J_history,h] = gradientdescent2(X,y,theta,alpha);
    z = temp1*theta;
    p = sigmoid(z);
    flag = length(X);
    m = 34-flag;
    test = temp1(1:m,:);
    p = p(1:m,:);
    temp1 = zeros(m,columns+1);
    
end
data = load('Dt.csv');
test = data(:,1:3);
test_norm = normalize(test);
l = length(test);
test = [ones(l,1) test_norm];
p = zeros(l,1);
z = test*theta;
p = sigmoid(z);

%% Without Self-training
p1 = zeros(l,1);
z = test*old_theta;
p1 = sigmoid(z);

count = length(p1);
S = 'Test data without using unlabeled data set is predicted as:';
disp(S);
for i=1:count
    if p1(i,:)<0.5
        S = 'Women';
        disp(S);
    else
        S = 'Men';
        disp(S);
    end
end
count = length(p);
S = ' Program paused. Press Enter to see the prediction using unlabeled data set:';
disp(S);
pause;
for i=1:count
    if p(i,:)<0.5
        S = 'Women';
        disp(S);
    else
        S = 'Men';
        disp(S);
    end
end
